<?php

    session_start();

    /* Destroy all session data */
    $_SESSION = [];
    session_destroy();

    /* Remove login cookies */
    setcookie('status', '', time() - 3600, '/');
    setcookie('user_role', '', time() - 3600, '/');
    setcookie('user_name', '', time() - 3600, '/');


    header("Location: ../../Login/View/Login.php");
    exit();
?>
